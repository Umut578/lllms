# LLLM - Local Large Language Model

LLLM, Windows, Linux, macOS ve Android/Termux ortamlarında çalışabilen, yerel ve uzaktaki LLM modellerini destekleyen bir açık kaynaklı AI platformudur.

## Özellikler

- **Çoklu motor desteği**: llama.cpp (yerel), OpenRouter API, NVIDIA NIM API
- **Modern web arayüzü**: Markdown ve kod blokları desteği, sohbet geçmişi, streaming yanıtlar
- **Terminal sohbet modu**: Sunucuya bağlanabilen local terminal sohbeti
- **Model yönetimi**: GGUF model indirme ve yönetim sistemi
- **Skills sistemi**: Eklentileri bağlama ve geliştirme
- **Özelleştirilebilir ayarlar**: Yapılandırma dosyası ve ortam değişkenleri ile API anahtarları

## Kurulum

### Bağımlılıklar

```bash
pip install -r requirements.txt
```

### Yapılandırma

İlk kullanımda `config/config.yaml` dosyasını düzenleyin veya otomatik olarak oluşturmak için:

```bash
python config/init_config.py
```

API anahtarlarını `config/config.yaml` yerine `.env` dosyasında girin:

```bash
OPENROUTER_API_KEY=your_openrouter_key
NVIDIA_API_KEY=your_nvidia_key
```

### Yerel Inference Motorunu Yükleyin

llama.cpp'yi yükle:

```bash
# LLaMA.cpp deposunu klonlayın
git clone https://github.com/ggerganov/llama.cpp.git
cd llama.cpp
make -j$(nproc) (Linux)
# ya da: mingw32-make -j$(nproc) (Windows)
```

ve `llama-cpp-python` önyüklenmiş olarak kurulmuş olmalıdır.

## Komut Seti

- `lllm run` - Yerel API ve web sunucusunu başlat
- `lllm terminal` - Terminal üzerinden AI sohbeti aç
- `lllm terminal -orkey` - OpenRouter API kullan
- `lllm terminal -nimkey` - NVIDIA NIM API kullan
- `lllm terminal -local false` - Yerel inference yerine seçilen uzak sağlayıcıyı kullan
- `lllm new models` - Model indirme ve yönetim sistemini aç
- `lllm new assets` - Assets klasörünü ZIP'e dönüştür
- `lllm new skills` - Skills dizinini ve yönetim sistemini hazırlarla
- `lllm skills list` - Skill listele
- `lllm skills create NAME` - Yeni skill oluştur
- `lllm skills delete NAME` belongs Skills listele - Skill sil
- `lllm ports login 4000` - Belirtilen porttaki LLLM servisine bağlan

## Web Arayüzü

Sunucu başlatıldıktan sonra tarayıcıda `http://localhost:4000/web` adresine giderek sohbet edebilirsiniz.

## Skills Geliştirme

Skills dizini, Python modüllerini içerir ve yeni beceriler eklemek için kullanılabilir.

```python
# Örnek skill
skills/example.py

class Skill:
    name = "example"
    description = "Örnek skill"

    def execute(self, context):
        # Beceriniz burada uygulanıyor
        return {"result": "Beceriniz çalışıyor!"}
```

## Temel Kullanım Örnekleri

### Web Arayüzü Üzerinden Sohbet Etme

```bash
# Sunucuyu başlat
lllm run

# https://localhost:4000 adresine gidin
# Model seçin ve sohbet edin
```

### Terminal Sohbeti Aç

```bash
lllm terminal
lllm terminal -orkey
lllm terminal -nimkey
```

### Model İndirme

```bash
lllm new models
# Model kurulum penceresi görünecek, GGUF indirin
```

### Skill Yönetimi

```bash
lllm skills list
lllm skills create whisper_transcriber
lllm skills delete whisper_transcriber
```

## Lisans

Bu proje MIT Lisansı altında lisanslanmıştır. Detaylar için LICENSE dosyasını inceleyin.

## Katkıda Bulunma

1. Göndermeden önce lütfen bir issue açın
2. Sözleşme kuralları takip edin
3. Her yeni özellik için testler ekleyin
4. Çalışan özellikleri öncelikle sunun
5. Projeyi güncel tutun

## İleri Düzey Kullanım

### Docker Desteklemesi

Docker desteği mevcuttur:

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "runner.py"]
```

### Android ve Termux

Termux'ta şu komutları çalıştırın:

```bash
pkg update && pkg install python git
pip install -r requirements.txt
```

### Yapılandırma

Yapılandırma dosyasını dilediğiniz gibi düzenleyin ve ortam değişkenlerini kullanın.

## Destek

Herhangi bir problem yaşarsanız:
- Lütfen önce bir issue oluşturun
- Zorunlu bilgi toplamak için yapay zekâ yardımını isteyin
- Yerel hata ayıklamayı kullanmak için `python debug.py` komutunu kullanın

## İleri Düzey Özellikler

- Model optimization (Q4_K_S, Q5_K_M vb.)
- Multimodal destek (görsel/ses)
- API proxy sunucusu
- Zamanlama etkileşimi
- CPU/GPU task scheduling
- Otomatik model güncelleme
- Modeller için batch processing
- Tek dosya yayılımı (`./lllm.py`)