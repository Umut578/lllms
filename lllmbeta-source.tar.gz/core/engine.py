#!/usr/bin/env python3
"""LLLM Core Inference Engine.

Yerel llama.cpp inference motoru ve uzak API sağlayıcıları için temel sınıflar.
"""

import os
import json
import logging
import requests
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Generator, Any
from pathlib import Path

# Yapılandırma yükleyici
def load_yaml_config(path: str) -> dict:
    import yaml
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


class InferenceEngine(ABC):
    """Inference motoru için temel soyut sınıf."""

    @abstractmethod
    def generate(self, messages: List[Dict], **kwargs) -> str:
        """Tam yanıt üret."""
        pass

    @abstractmethod
    def generate_stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]:
        """Streaming yanıt üret."""
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """Motorun hazır olup olmadığını kontrol et."""
        pass


class LocalEngine(InferenceEngine):
    """llama.cpp tabanlı yerel inference motoru."""

    def __init__(self, config: dict):
        self.config = config
        self.model_path = config.get("local", {}).get("gguf_path", "models")
        self.default_model = config.get("local", {}).get("default_model", "")
        self.n_ctx = config.get("local", {}).get("n_ctx", 4096)
        self.n_gpu_layers = config.get("model", {}).get("n_gpu_layers", 0)
        self.n_threads = config.get("model", {}).get("n_threads", 4)
        self.temperature = config.get("model", {}).get("temperature", 0.7)
        self.top_p = config.get("model", {}).get("top_p", 0.9)
        self.max_tokens = config.get("model", {}).get("max_tokens", 2048)
        self.llama = None
        self._init_model()

    def _init_model(self):
        """llama-cpp-python ile modeli yükle."""
        try:
            from llama_cpp import Llama
        except ImportError:
            logging.warning("llama-cpp-python yüklü değil. Yerel motor kullanılamaz.")
            return

        model_files = list(Path(self.model_path).glob("*.gguf"))
        if not model_files:
            logging.warning(f"Models klasöründe GGUF dosyası yok: {self.model_path}")
            return

        model_file = Path(self.default_model) if self.default_model else model_files[0]
        if not model_file.exists():
            model_file = model_files[0]

        logging.info(f"Yerel model yükleniyor: {model_file}")

        try:
            self.llama = Llama(
                model_path=str(model_file),
                n_ctx=self.n_ctx,
                n_gpu_layers=self.n_gpu_layers,
                n_threads=self.n_threads,
                verbose=False,
            )
            logging.info("Yerel model başarıyla yüklendi.")
        except Exception as e:
            logging.error(f"Model yüklenemedi: {e}")
            self.llama = None

    def is_available(self) -> bool:
        return self.llama is not None

    def _messages_to_prompt(self, messages: List[Dict]) -> str:
        """Mesajları llama.cpp prompt formatına çevir."""
        prompt = ""
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                prompt += f"<|system|>\n{content}\n"
            elif role == "user":
                prompt += f"<|user|>\n{content}\n"
            elif role == "assistant":
                prompt += f"<|assistant|>\n{content}\n"
        prompt += "<|assistant|>\n"
        return prompt

    def generate(self, messages: List[Dict], **kwargs) -> str:
        if not self.is_available():
            return "❌ Yerel motor kullanılabilir değil. Model yüklü değil."

        temp = kwargs.get("temperature", self.temperature)
        top_p = kwargs.get("top_p", self.top_p)
        max_tokens = kwargs.get("max_tokens", self.max_tokens)

        prompt = self._messages_to_prompt(messages)

        try:
            output = self.llama(
                prompt,
                max_tokens=max_tokens,
                temperature=temp,
                top_p=top_p,
                stop=["<|user|>", "<|system|>"],
                echo=False,
            )
            return output["choices"][0]["text"].strip()
        except Exception as e:
            logging.error(f"Yerel inference hatası: {e}")
            return f"❌ Hata: {e}"

    def generate_stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]:
        if not self.is_available():
            yield "❌ Yerel motor kullanılabilir değil."
            return

        temp = kwargs.get("temperature", self.temperature)
        top_p = kwargs.get("top_p", self.top_p)
        max_tokens = kwargs.get("max_tokens", self.max_tokens)

        prompt = self._messages_to_prompt(messages)

        try:
            stream = self.llama(
                prompt,
                max_tokens=max_tokens,
                temperature=temp,
                top_p=top_p,
                stop=["<|user|>", "<|system|>"],
                stream=True,
            )
            for chunk in stream:
                token = chunk["choices"][0]["text"]
                if token:
                    yield token
        except Exception as e:
            logging.error(f"Yerel streaming hatası: {e}")
            yield f"❌ Hata: {e}"


class RemoteEngine(InferenceEngine):
    """Uzak API sağlayıcıları için temel sınıf (OpenRouter, NIM)."""

    def __init__(self, config: dict, provider: str):
        self.config = config
        self.provider = provider
        self.base_url = config.get(provider, {}).get("base_url", "")
        self.model = config.get(provider, {}).get("model", "")
        self.api_key = self._resolve_api_key(config.get(provider, {}).get("api_key", ""))

    def _resolve_api_key(self, key: str) -> str:
        """API anahtarını environment değişkeninden çözümle."""
        if key.startswith("${") and key.endswith("}"):
            env_var = key[2:-1]
            return os.environ.get(env_var, "")
        return key

    def is_available(self) -> bool:
        return bool(self.api_key and self.base_url)

    def _build_request(self, messages: List[Dict], stream: bool = False) -> Dict:
        return {
            "model": self.model,
            "messages": messages,
            "stream": stream,
            "temperature": self.config.get("model", {}).get("temperature", 0.7),
            "top_p": self.config.get("model", {}).get("top_p", 0.9),
            "max_tokens": self.config.get("model", {}).get("max_tokens", 2048),
        }

    def _headers(self) -> Dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def generate(self, messages: List[Dict], **kwargs) -> str:
        if not self.is_available():
            return f"❌ {self.provider} kullanılamıyor. API anahtarı gerekli."

        try:
            resp = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._headers(),
                json=self._build_request(messages, stream=False),
                timeout=120,
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()
        except Exception as e:
            logging.error(f"{self.provider} inference hatası: {e}")
            return f"❌ {self.provider} hatası: {e}"

    def generate_stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]:
        if not self.is_available():
            yield f"❌ {self.provider} kullanılamıyor. API anahtarı gerekli."
            return

        try:
            with requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._headers(),
                json=self._build_request(messages, stream=True),
                timeout=120,
                stream=True,
            ) as resp:
                resp.raise_for_status()
                for line in resp.iter_lines():
                    if line:
                        line = line.decode("utf-8")
                        if line.startswith("data: "):
                            data = line[6:]
                            if data == "[DONE]":
                                break
                            try:
                                chunk = json.loads(data)
                                if "choices" in chunk and chunk["choices"]:
                                    delta = chunk["choices"][0].get("delta", {})
                                    if "content" in delta:
                                        yield delta["content"]
                            except json.JSONDecodeError:
                                continue
        except Exception as e:
            logging.error(f"{self.provider} streaming hatası: {e}")
            yield f"❌ {self.provider} hatası: {e}"


class OpenRouterEngine(RemoteEngine):
    """OpenRouter API motoru."""

    def __init__(self, config: dict):
        super().__init__(config, "openrouter")


class NIMEngine(RemoteEngine):
    """NVIDIA NIM API motoru."""

    def __init__(self, config: dict):
        super().__init__(config, "nim")


class EngineManager:
    """Tüm inference motorlarını yöneten merkezi sınıf."""

    def __init__(self, config: dict):
        self.config = config
        self.engines = {
            "local": LocalEngine(config),
            "openrouter": OpenRouterEngine(config),
            "nim": NIMEngine(config),
        }
        self.current_provider = config.get("model", {}).get("default_provider", "local")

    def get_engine(self, provider: Optional[str] = None) -> InferenceEngine:
        provider = provider or self.current_provider
        return self.engines.get(provider, self.engines["local"])

    def set_provider(self, provider: str):
        if provider in self.engines:
            self.current_provider = provider

    def list_available_providers(self) -> List[str]:
        return [name for name, engine in self.engines.items() if engine.is_available()]

    def generate(self, messages: List[Dict], provider: Optional[str] = None, **kwargs) -> str:
        engine = self.get_engine(provider)
        return engine.generate(messages, **kwargs)

    def generate_stream(self, messages: List[Dict], provider: Optional[str] = None, **kwargs) -> Generator[str, None, None]:
        engine = self.get_engine(provider)
        yield from engine.generate_stream(messages, **kwargs)