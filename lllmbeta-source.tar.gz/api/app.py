#!/usr/bin/env python3
"""LLLM Main Application Entry Point."""

import os
from api.routes import app
from core.engine import EngineManager
import yaml
import threading

def main():
    """Ana uygulama fonksiyonu."""
    config = yaml.safe_load(open("config/config.yaml", "r", encoding="utf-8"))
    
    # Sunucu ayarları
    host = config.get("app", {}).get("host", "0.0.0.0")
    port = config.get("app", {}).get("port", 4000)
    debug = config.get("app", {}).get("debug", False)
    
    print(f"🚀 LLLM Sunucu başlatılıyor...")
    print(f"   Host: {host}")
    print(f"   Port: {port}")
    print(f"   Debug: {debug}")
    
    # Motor durum kontrolü
    engine_manager = EngineManager(config)
    available = engine_manager.list_available_providers()
    if available:
        print(f"   Mevcut motorlar: {', '.join(available)}")
    else:
        print("   ❌ Hiçbir motor bulunamadı!")
        return
    
    # Flask uygulamasını başlat
    print("🌐 Web arayüzü: http://localhost:{port}")
    print("💡 API endpoint'leri: /api/status, /chat, /chat/stream")
    app.run(host=host, port=port, debug=debug)

if __name__ == "__main__":
    main()