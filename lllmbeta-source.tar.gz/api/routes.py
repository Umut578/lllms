#!/usr/bin/env python3
"""LLLM API Routes - Flask/FastAPI endpoints."""

from flask import Flask, render_template, request, jsonify
from core.engine import EngineManager, load_yaml_config
import os

app = Flask(__name__)
engine_manager = EngineManager(load_yaml_config("config/config.yaml"))


@app.route("/")
def index():
    """Ana sohbet sayfası."""
    providers = engine_manager.list_available_providers()
    return jsonify({
        "providers": providers,
        "current_provider": engine_manager.current_provider,
        "status": "ok"
    })


@app.route("/chat", methods=["POST"])
def chat():
    """Chat endpoint - mesaj gönder."""
    data = request.get_json()
    messages = data.get("messages", [])
    provider = data.get("provider", None)

    if not messages:
        return jsonify({"error": "Messages gerekli"}), 400

    result = engine_manager.generate(messages, provider=provider)
    return jsonify({"response": result, "provider": provider or "local"})


@app.route("/chat/stream", methods=["POST"])
def chat_stream():
    """Streaming chat endpoint."""
    data = request.get_json()
    messages = data.get("messages", [])
    provider = data.get("provider", None)

    if not messages:
        return jsonify({"error": "Messages gerekli"}), 400

    def generate():
        for token in engine_manager.generate_stream(messages, provider=provider):
            yield f"data: {json.dumps({'token': token})}\n\n"

    return app.response_class(generate(), mimetype="text/event-stream")


@app.route("/models", methods=["GET"])
def list_models():
    """Models listele."""
    config = load_yaml_config("config/config.yaml")
    models_dir = config.get("model", {}).get("models_dir", "models")
    models_path = Path(models_dir)
    model_files = []
    if models_path.exists():
        for f in sorted(models_path.iterdir()):
            if f.is_file() and f.suffix in [".gguf", ".bin", ".safetensors"]:
                model_files.append(f.name)
    return jsonify({"models": model_files})


@app.route("/skills", methods=["GET"])
def list_skills():
    """Skills listele."""
    skills_dir = Path("skills")
    skills = []
    if skills_dir.exists():
        for f in sorted(skills_dir.iterdir()):
            if f.is_file() and f.suffix == ".py":
                skills.append(f.name[:-3])
    return jsonify({"skills": skills})


@app.route("/skills/create", methods=["POST"])
def create_skill():
    """Yeni skill oluştur."""
    data = request.get_json()
    name = data.get("name", "").strip()
    if not name:
        return jsonify({"error": "Skill adı gerekli"}), 400

    skill_path = Path(f"skills/{name}.py")
    if skill_path.exists():
        return jsonify({"error": "Bu isimde bir skill zaten var"}), 409

    skill_path.write_text(f'"""Skill: {name}"""\\n\\n', encoding="utf-8")
    return jsonify({"status": "ok", "skill": name})


@app.route("/skills/delete", methods=["POST"])
def delete_skill():
    """Skill sil."""
    data = request.get_json()
    name = data.get("name", "").strip()
    if not name:
        return jsonify({"error": "Skill adı gerekli"}), 400

    skill_path = Path(f"skills/{name}.py")
    if skill_path.exists():
        skill_path.unlink()
        return jsonify({"status": "ok", "skill": name})
    return jsonify({"error": "Skill bulunamadı"}), 404


@app.route("/settings", methods=["GET", "POST"])
def settings():
    """Ayarlar endpoint'i."""
    if request.method == "GET":
        config = load_yaml_config("config/config.yaml")
        return jsonify(config)
    else:
        data = request.get_json()
        # Yapılandırmayı güncelle
        config_path = "config/config.yaml"
        with open(config_path, "w", encoding="utf-8") as f:
            import yaml
            yaml.dump(data, f, default_flow_style=False)
        return jsonify({"status": "ok"})


@app.route("/api/status")
def api_status():
    """API durumu."""
    config = load_yaml_config("config/config.yaml")
    providers = engine_manager.list_available_providers()
    return jsonify({
        "providers": providers,
        "port": config.get("app", {}).get("port", 4000),
        "status": "running"
    })


# Template rotaları için statik sayfa render
@app.route("/web")
def web():
    """Web arayüzü sayfası."""
    return render_template("chat.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=4000, debug=True)