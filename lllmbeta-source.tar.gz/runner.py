#!/usr/bin/env python3
"""LLLM - Local Large Language Model CLI and Core Logic."""

import sys
import argparse
import os
import yaml 
import json
import logging
import subprocess
import threading
import time
from pathlib import Path
from typing import List, Dict, Any, Generator

# Path configuration
BASE_DIR = Path(__file__).parent
CONFIG_PATH = BASE_DIR / "config" / "config.yaml"
LOG_DIR = BASE_DIR / "logs"
MODELS_DIR = BASE_DIR / "models"
SKILLS_DIR = BASE_DIR / "skills"
ASSETS_DIR = BASE_DIR / "assets"
DOWNLOADS_DIR = BASE_DIR / "downloads"

# Logging setup
def setup_logging():
    log_dir = LOG_DIR
    log_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_dir / "lllm.log"),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return log_dir

# Configuration loader
def load_config():
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception as e:
        logging.error(f"Config dosyası okunamadı: {e}")
        return None

# Model management
def list_models(config):
    models_dir = Path(config.get("model", {}).get("models_dir", "models"))
    if not models_dir.exists():
        logging.warning(f"Models klasörü bulunamadı: {models_dir}")
        return []
    model_files = []
    for f in sorted(models_dir.iterdir()):
        if f.is_file() and f.suffix in [".gguf", ".bin", ".safetensors"]:
            model_files.append(f.name)
    return model_files

def create_assets_archive(config):
    assets_dir = Path(config.get("assets", {}).get("dir", "assets"))
    if not assets_dir.exists():
        logging.warning(f"Assets klasörü bulunamadı: {assets_dir}")
        return False
    DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
    archive_path = DOWNLOADS_DIR / "assets.zip"
    try:
        import shutil
        shutil.make_archive(str(archive_path.with_suffix('')), 'zip', root_dir=str(assets_dir), base_dir='.')
        logging.info(f"Assets ZIP dosyası oluşturuldu: {archive_path}")
        return True
    except Exception as e:
        logging.error(f"Assets ZIP oluşturulamadı: {e}")
        return False

# Skills management
def list_skills(config):
    skills_dir = Path(config.get("skills", {}).get("dir", "skills"))
    if not skills_dir.exists():
        logging.warning(f"Skills klasörü bulunamadı: {skills_dir}")
        return []
    skills = []
    for f in sorted(skills_dir.iterdir()):
        if f.is_file() and f.suffix == ".py":
            skills.append(f.stem)
    return skills

def create_skill(name):
    skill_path = SKILLS_DIR / f"{name}.py"
    if skill_path.exists():
        logging.error(f"Skill '{name}' zaten var")
        return False
    content = f'# {name}\n\nclass Skill:\n    name = "{name}"\n    description = "Yeni skill"\n\n    def execute(self, context):\n        return {{"status": "success"}}\n'
    try:
        skill_path.write_text(content, encoding="utf-8")
        logging.info(f"Skill '{name}' oluşturuldu")
        return True
    except Exception as e:
        logging.error(f"Skill oluşturulamadı: {e}")
        return False

def delete_skill(name):
    skill_path = SKILLS_DIR / f"{name}.py"
    if skill_path.exists():
        try:
            skill_path.unlink()
            logging.info(f"Skill '{name}' silindi")
            return True
        except Exception as e:
            logging.error(f"Skill silme hatası: {e}")
            return False
    logging.error(f"Skill '{name}' bulunamadı")
    return False

# Port management
def ports_login(port):
    # Simple check: try to connect to localhost on port
    try:
        import socket
        port_num = int(port) if port else 4000
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('127.0.0.1', port_num))
        sock.close()
        if result == 0:
            logging.info(f"Port {port_num} LLLM servisine bağlı")
        else:
            logging.warning(f"Port {port_num} açıklıkta: {result}")
    except Exception as e:
        logging.error(f"Port kontrol hatası: {e}")

def run_terminal(config, args):
    # Determine provider
    use_local = True
    provider = "local"
    
    # --local true/false flag (string)
    if args.local == "false":
        use_local = False
        # Try to detect provider based on config
        providers = config.get("model", {}).get("providers", ["local"])
        if "openrouter" in providers:
            provider = "openrouter"
        elif "nim" in providers:
            provider = "nim"
        else:
            provider = "local"
    
    # -orkey overrides to OpenRouter
    if args.orkey:
        use_local = False
        provider = "openrouter"
    # -nimkey overrides to NIM
    if args.nimkey:
        use_local = False
        provider = "nim"
    
    if not use_local:
        # Remote mode - need to check if remote API is available
        remote_config = config.get(provider, {})
        if not remote_config.get("base_url") or not remote_config.get("api_key"):
            logging.error(f"{provider} API ayarları eksik. API anahtarını yapılandırın.")
            return
    
    # Run the terminal sohbeti (this is just UI for now)
    logging.info(f"Terminal sohbeti {provider} üzerinden başlatılıyor...")
    if not use_local:
        logging.info("Uzak API kullanımı için uygun bir terminal uygulama gerekir.")
    else:
        logging.info("Yerel inference kullanılarak sohbet açılıyor.")
        # For now, just show a message
        print("💬 Terminal sohbeti açıldı. (Gelecekte tam implementasyon yapılacak)")

# Main entry point
def main():
    parser = argparse.ArgumentParser(description="LLLM - Local Large Language Model")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # run
    sub_run = subparsers.add_parser("run", help="Start local API and web server")
    sub_run.add_argument("--debug", action="store_true", help="Enable debug mode")
    
    # terminal
    sub_term = subparsers.add_parser("terminal", help="Open AI terminal")
    sub_term.add_argument("-orkey", "--orkey", action="store_true", help="Use OpenRouter API")
    sub_term.add_argument("-nimkey", "--nimkey", action="store_true", help="Use NVIDIA NIM API")
    sub_term.add_argument("-local", "--local", type=str, choices=["true", "false"], 
                           default="true", help="Use local inference (true/false)")
    
    # new
    sub_new = subparsers.add_parser("new", help="Create new resource")
    sub_new.add_argument("type", choices=["models", "assets", "skills", "folder"], 
                          help="Resource type to create")
    sub_new.add_argument("name", nargs="?", help="Optional name")
    
    # skills
    sub_skills = subparsers.add_parser("skills", help="Skill management")
    sub_skills.add_argument("action", choices=["list", "create", "delete"], 
                              help="Action to perform")
    sub_skills.add_argument("name", nargs="?", help="Skill name for create/delete")
    
    # ports
    sub_ports = subparsers.add_parser("ports", help="Port management")
    sub_ports.add_argument("action", choices=["login"], help="Port action")
    sub_ports.add_argument("port", nargs="?", help="Port number")
    
    args = parser.parse_args()
    
    config = load_config()
    if not config:
        sys.exit(1)
    
    logging.info(f"LLLM v{config.get('app', {}).get('version', '1.0.0')} başlatılıyor")
    
    if args.command == "run":
        # Start the web server in a thread
        def start_server():
            from api.app import app
            app.run(host=config.get("app", {}).get("host", "0.0.0.0"), 
                   port=config.get("app", {}).get("port", 4000), 
                   debug=config.get("app", {}).get("debug", False))
        
        server_thread = threading.Thread(target=start_server, daemon=True)
        server_thread.start()
        logging.info("Web sunucusu başlatıldı")
        print("🚀 LLLM web sunucusu başlatıldı")
        print(f"   Tarayıcıda http://localhost:{config.get('app', {}).get('port', 4000)} adresine gidin")
        print("   Ctrl+C ile durdurulabilir")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 Sunucu durduruldu")
            
    elif args.command == "terminal":
        run_terminal(config, args)
        
    elif args.command == "new":
        if args.type == "models":
            files = list_models(config)
            if files:
                print(f"📁 Kayıtlı modeller ({len(files)}):")
                for f in files:
                    print(f"   - {f}")
            else:
                print("📁 Models klasörü boş veya bulunamadı")
        elif args.type == "assets":
            create_assets_archive(config)
        elif args.type == "skills":
            if args.name:
                create_skill(args.name)
            else:
                print("📁 Skills yönetimi için 'lllm new skills' veya 'lllm skills create NAME' kullanın")
        elif args.type == "folder":
            # For now, just create a folder
            folder_name = args.name or "new_folder"
            folder_path = BASE_DIR / folder_name
            try:
                folder_path.mkdir(parents=True, exist_ok=True)
                print(f"📁 Klasör oluşturuldu: {folder_path}")
            except Exception as e:
                print(f"❌ Klasör oluşturulamadı: {e}")
                
    elif args.command == "skills":
        if args.action == "list":
            skills = list_skills(config)
            if skills:
                print("📁 Mevcut Skills:")
                for skill in skills:
                    print(f"   - {skill}")
            else:
                print("📁 Skills klasörü boş veya bulunamadı")
        elif args.action == "create":
            if args.name:
                if create_skill(args.name):
                    print(f"✅ Skill '{args.name}' oluşturuldu")
                else:
                    print(f"❌ Skill '{args.name}' oluşturulamadı")
            else:
                print("❌ Lütfen skill adı belirtin: lllm skills create NAME")
        elif args.action == "delete":
            if args.name:
                if delete_skill(args.name):
                    print(f"🗑️ Skill '{args.name}' silindi")
                else:
                    print(f"❌ Skill '{args.name}' silinemezdi")
            else:
                print("❌ Lütfen skill adı belirtin: lllm skills delete NAME")
                
    elif args.command == "ports":
        if args.action == "login" and args.port:
            ports_login(args.port)
        else:
            print("📋 Komut kullanımı: lllm ports login 4000")
            
    else:
        print("""
LLLM - Local Large Language Model
Kullanım:

  lllm run                          # Yerel API ve web sunucusunu başlat
  lllm terminal                     # Terminal üzerinden AI sohbeti aç
  lllm terminal -orkey              # OpenRouter API kullan
  lllm terminal -nimkey             # NVIDIA NIM API kullan
  lllm terminal -local false        # Yerel inference yerine uzak sağlayıcıyı kullan
  lllm new models                   # Model indirme ve yönetim sistemini aç
  lllm new assets                   # Assets klasörünü ZIP'e dönüştür
  lllm new skills                   # Skills dizinini ve yönetim sistemini hazırla
  lllm new folder                   # Yeni klasör oluştur
  lllm skills list                  # Skill listele
  lllm skills create NAME           # Yeni skill oluştur
  lllm skills delete NAME           # Skill sil
  lllm ports login 4000             # Porttaki LLLM servisine bağla
        """)

if __name__ == "__main__":
    main()
